import pandas as pd
import warnings
warnings.filterwarnings('ignore')
import time

start = time.time()

df = pd.read_csv('bank-full.csv')
contador = df.groupby(['job','housing','loan']).size().reset_index(name='counts')

maior = 0
razao = []
for i in range(len(contador['counts'])):
    if i%4==0:
        frac = (contador['counts'][i+1]+contador['counts'][i+2]+contador['counts'][i+3])/(contador['counts'][i]+contador['counts'][i+1]+contador['counts'][i+2]+contador['counts'][i+3])
        razao.append(frac)
        if frac>maior:
            maior = frac
            indice = i
            jobb = contador['job'][indice]

housing = contador['counts'][indice+2]+contador['counts'][indice+3]
loan = contador['counts'][indice+1]+contador['counts'][indice+3]
if housing>loan:
    emprestimo = 'housing'
else:
    emprestimo = 'loan'
maior = maior*100
maior = round(maior,3)
print('Questão 1 - A profissão com maior tendência a fazer um empréstimo é '+jobb+', com '+str(maior)+'% de incidência. O tipo mais comum de empréstimo é '+emprestimo+'.')


contatos = df.groupby(['campaign','y']).size().reset_index(name='counts')

sucesso = []
atual = contatos['campaign'][0]
i = 0
while i<(len(contatos['counts'])-1):
    proximo = contatos['campaign'][i+1]
    if proximo == atual:
        frac = contatos['counts'][i+1]/(contatos['counts'][i]+contatos['counts'][i+1])
        sucesso.append(frac)
        i += 2
        atual = contatos['campaign'][i]
    else:
        sucesso.append(0)
        i += 1
        atual = contatos['campaign'][i]

var = 0
sucesso.insert(0,var)
import matplotlib.pyplot as plt        
plt.plot(sucesso)
plt.grid()
plt.xlabel('Número de contatos realizados')
plt.ylabel('Proporção dos que aderiram à campanha (%)') 

print('\n')

print('Questão 2 - Como pode ser observado no gráfico e na variável "contatos", a taxa de contratação segue uma tendência de queda até que o número de contatos seja próximo a 12, sendo que depois disso, a quantidade de indivíduos que aderiram à campanha se torna muito pequena para realizar análises conclusivas.')
print('\n\n')
print(contatos)

print('\n\n')
print('Questão 3 - Ainda se baseando no gráfico, o número máximo de contatos recomendado seria 10, já que ainda há uma quantidade significativa de indivíduos analisados e a adesão ainda é relativamente alta. Após esse valor, além de a adesão continuar caindo, a siginificância do número de indivíduos analisados já não pode mais ser considerada de comportamento assintótico, de modo que aestatística não é confiável.')
print('Observando ainda os dados, um valor médio de 6 ligações estaria coerente com o fato de que, nessa número, ainda existe cerca de metade (7,1%) da adesão máxima de cerca de 14,6% de uma ligação.')
print('\n\n')

previsao = df.groupby(['poutcome','y']).size().reset_index(name='counts')
print(previsao)
print('Questão 4 - Como podemos ver na tabela relacionando potcome com y, a maioria esmagadora dos dados do ano anterior são desconhecidos, portanto, não é posśivel realizar previsão usando os mesmos. No entanto, usando uma dense neural network com todas as características, é possível estimar a saída y com cerca de 90% de precisão. O código para fazê-lo é nn.py.')

df['balance'] = pd.cut(df['balance'],10)
df['age'] = pd.cut(df['age'],6)



features = ['age','job','marital','education','balance','housing','loan']
credito = []
i = 0
while i<len(features):
    credito.append([])
    i += 1

k = 0
banco = []
for j in features:
    verification = df.groupby([j,'default']).size().reset_index(name='counts')
    #print(verification)
    atual = verification[j][0]
    i = 0
    while i<(len(verification['counts'])-1):
        proximo = verification[j][i+1]
        if proximo == atual:
            frac = verification['counts'][i+1]/(verification['counts'][i]+verification['counts'][i+1])
            credito[k].append(frac)
            i += 2
            if i>len(verification['counts'])-1:
                break
            atual = verification[j][i]
        else:
            credito[k].append(0)
            i += 1
            if i>len(verification['counts'])-1:
                break
            atual = verification[j][i]
    banco.append(sum(credito[k])/len(credito[k]))
    k += 1
print('\n\n')
print('Questão 5 - Como podemos ver na variável "credito", os fatores que mais importam para o atributo "default" são: idade entre 18 e 31 anos e a profissão entrepreuneur.')
print('\n\n')

features = ['age','job','marital','education','balance','default','loan']
credito = []
i = 0
while i<len(features):
    credito.append([])
    i += 1

k = 0
banco = []
for j in features:
    verification = df.groupby([j,'housing']).size().reset_index(name='counts')
    #print(verification)
    atual = verification[j][0]
    i = 0
    while i<(len(verification['counts'])-1):
        proximo = verification[j][i+1]
        if proximo == atual:
            frac = verification['counts'][i+1]/(verification['counts'][i]+verification['counts'][i+1])
            credito[k].append(frac)
            i += 2
            if i>len(verification['counts'])-1:
                break
            atual = verification[j][i]
        else:
            credito[k].append(0)
            i += 1
            if i>len(verification['counts'])-1:
                break
            atual = verification[j][i]
    banco.append(sum(credito[k])/len(credito[k]))
    k += 1

print('Pela variável "credito", observamos o seguinte: 63% dos indivíduos entre 31 e 43 e 72% dos que trabalham em "blue-collar", sendo essas as características que mais se destacam.')
end = time.time()

print('\n\n')
elapsed = round(end-start,3)
print('O tempo total de execução deste código é '+str(elapsed)+' segundo')