import pandas as pd
import tensorflow as tf
import warnings
warnings.filterwarnings('ignore')
import time

start = time.time()

df = pd.read_csv('bank-full.csv')

labels = df['y']
out = []
for i in range(len(labels)):
    if labels[i] == 'yes':
        out.append(1) 
    else:
        out.append(0)

out_df = pd.DataFrame({'col':out})
labels = out_df['col']
df['y'] = labels

cols_to_norm = ['balance','duration','campaign','pdays','previous']
df[cols_to_norm] = df[cols_to_norm].apply(lambda x: (x-x.min())/(x.max()-x.min()))

age = tf.feature_column.numeric_column('age')
balance = tf.feature_column.numeric_column('balance')
day = tf.feature_column.numeric_column('day')
pdays = tf.feature_column.numeric_column('pdays')
duration = tf.feature_column.numeric_column('duration')
campaign = tf.feature_column.numeric_column('campaign')
previous = tf.feature_column.numeric_column('previous')

age_bucket = tf.feature_column.bucketized_column(age,boundaries = [10,20,30,40,50,60,70,80,90])

job = tf.feature_column.categorical_column_with_hash_bucket('job',hash_bucket_size=20)
marital = tf.feature_column.categorical_column_with_hash_bucket('marital',hash_bucket_size=6)
education = tf.feature_column.categorical_column_with_hash_bucket('education',hash_bucket_size=5)
default = tf.feature_column.categorical_column_with_hash_bucket('default',hash_bucket_size=2)
housing =tf.feature_column.categorical_column_with_hash_bucket('housing',hash_bucket_size=2)
loan = tf.feature_column.categorical_column_with_hash_bucket('loan',hash_bucket_size=2)
contact = tf.feature_column.categorical_column_with_hash_bucket('contact',hash_bucket_size=3)
month = tf.feature_column.categorical_column_with_hash_bucket('month',hash_bucket_size=12)
poutcome = tf.feature_column.categorical_column_with_hash_bucket('poutcome',hash_bucket_size=4)

feat_cols = [age_bucket,marital,education,default,balance,housing,loan,contact,day,month,duration,campaign,pdays,previous,poutcome]

x_data = df.drop('y',axis=1)
labels = df['y']

from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(x_data,labels,test_size = 0.3, random_state = 101)
input_func = tf.estimator.inputs.pandas_input_fn(x=X_train,y=y_train,batch_size=10,num_epochs=1000,shuffle=True)

embedded_marital = tf.feature_column.embedding_column(marital,dimension=6)
embedded_education = tf.feature_column.embedding_column(education,dimension=5)
embedded_default = tf.feature_column.embedding_column(default,dimension=2)
embedded_housing = tf.feature_column.embedding_column(housing,dimension=2)
embedded_loan = tf.feature_column.embedding_column(loan,dimension=2)
embedded_contact = tf.feature_column.embedding_column(contact,dimension=3)
embedded_month = tf.feature_column.embedding_column(month,dimension=12)
embedded_poutcome = tf.feature_column.embedding_column(poutcome,dimension=4)

feat_cols = [age_bucket,embedded_marital,embedded_education,embedded_default,balance,embedded_housing,embedded_loan,embedded_contact,day,embedded_month,duration,campaign,pdays,previous,embedded_poutcome]
input_func = tf.estimator.inputs.pandas_input_fn(x=X_train,y=y_train,batch_size=10,num_epochs=1000,shuffle=True)
dnn_model = tf.estimator.DNNClassifier(hidden_units=[16,20,20,16],feature_columns=feat_cols,n_classes=2)
dnn_model.train(input_fn=input_func,steps = 5000)

eval_input_func = tf.estimator.inputs.pandas_input_fn(x=X_test,y=y_test,batch_size=10,shuffle=False)

print(dnn_model.evaluate(eval_input_func))

end = time.time()
print(end-start)